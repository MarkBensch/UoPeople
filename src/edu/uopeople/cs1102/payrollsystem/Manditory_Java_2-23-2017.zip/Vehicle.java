package edu.uopeople.projectone.payrollsystem;

/**
 * Created by MarkTurnTo on 2/23/17.
 */
public class Vehicle {



}
