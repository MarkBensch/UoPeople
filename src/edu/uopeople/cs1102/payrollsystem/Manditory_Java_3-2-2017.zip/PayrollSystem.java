package edu.uopeople.projectone.payrollsystem;

import java.util.ArrayList;

/**
 * Created by MarkTurnTo on 2/23/17.
 */
public class PayrollSystem {
    public static void main(String[] arguments) {

    }

    public FullTime readNewFullTime(){
        return null;
    }

    public PartTime readNewPartTime(){
        return null;
    }

    public void addEmployee(ArrayList<Employee> pArrEmp, Employee pEmp ){

    }

    public void calcPayroll(ArrayList<Employee> pArrEmp){

    }

    public byte showMenu(){
        return 0;
    }

    public Vehicle getVehicle(){
        return null;
    }
}